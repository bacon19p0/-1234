package com.nationwar;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;

/** 내 국가 땅의 가장자리 블록 위 1칸에 초록색 입자를 일렁이게 표시한다. (본인 화면에만 보임) */
public final class BorderRenderer {
    private static final Particle.DustOptions GREEN = new Particle.DustOptions(Color.fromRGB(60, 230, 90), 1.2f);

    private final NationWarPlugin plugin;
    private final NationManager m;

    public BorderRenderer(NationWarPlugin plugin, NationManager m) {
        this.plugin = plugin;
        this.m = m;
    }

    public void start() {
        long interval = Math.max(2, plugin.getConfig().getInt("border.interval-ticks", 8));
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, interval);
    }

    private void tick() {
        if (!plugin.getConfig().getBoolean("border.enabled", true)) return;
        int r = plugin.getConfig().getInt("border.radius", 20);
        double t = System.currentTimeMillis() / 250.0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!m.isBorderOn(p.getUniqueId())) continue; // 개인별 끄기
            Nation n = m.nationOf(p.getUniqueId());
            if (n == null) continue;
            Location l = p.getLocation();
            World w = l.getWorld();
            int px = l.getBlockX(), pz = l.getBlockZ();
            for (Claim c : m.claimsInArea(w.getName(), px - r, pz - r, px + r, pz + r)) {
                if (c.nation.equals(n.id)) renderEdges(p, w, c, px, pz, r, t);
            }
        }
    }

    private void renderEdges(Player p, World w, Claim c, int px, int pz, int r, double t) {
        int minX = Math.max(c.x1, px - r), maxX = Math.min(c.x2, px + r);
        int minZ = Math.max(c.z1, pz - r), maxZ = Math.min(c.z2, pz + r);
        // 위/아래 가장자리 (z 고정)
        if (c.z1 >= pz - r && c.z1 <= pz + r) for (int x = minX; x <= maxX; x++) dot(p, w, x, c.z1, t);
        if (c.z2 != c.z1 && c.z2 >= pz - r && c.z2 <= pz + r) for (int x = minX; x <= maxX; x++) dot(p, w, x, c.z2, t);
        // 좌/우 가장자리 (x 고정, 모서리 중복 제외)
        int zs = Math.max(minZ, c.z1 + 1), ze = Math.min(maxZ, c.z2 - 1);
        if (c.x1 >= px - r && c.x1 <= px + r) for (int z = zs; z <= ze; z++) dot(p, w, c.x1, z, t);
        if (c.x2 != c.x1 && c.x2 >= px - r && c.x2 <= px + r) for (int z = zs; z <= ze; z++) dot(p, w, c.x2, z, t);
    }

    private void dot(Player p, World w, int x, int z, double t) {
        if (!w.isChunkLoaded(x >> 4, z >> 4)) return;
        int y = w.getHighestBlockYAt(x, z);
        double yy = y + 1.15 + 0.12 * Math.sin(t + (x + z) * 0.5); // 일렁이는 효과
        p.spawnParticle(Particle.DUST, x + 0.5, yy, z + 0.5, 1, 0, 0, 0, 0, GREEN);
    }
}
