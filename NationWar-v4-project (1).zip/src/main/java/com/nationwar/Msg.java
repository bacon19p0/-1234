package com.nationwar;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;

public final class Msg {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    public static final String PREFIX = "<gold>[국가전쟁]</gold> ";

    private Msg() {}

    public static Component c(String s) { return MM.deserialize(s); }

    public static Component item(String s) {
        return MM.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public static String esc(String s) { return MM.escapeTags(s); }

    public static void send(CommandSender to, String s) { to.sendMessage(c(PREFIX + s)); }
}
