package com.nationwar;

import java.util.UUID;

/** 블록 단위 직사각형 땅. y(높이)는 제한 없이 전부 포함. */
public final class Claim {
    public final UUID id;
    public final String world;
    public final int x1, z1, x2, z2;   // 포함 범위 (x1<=x2, z1<=z2)
    public UUID owner;                 // 땅 주인(플레이어)
    public UUID nation;                // 소속 국가
    public boolean annexed;            // 병합으로 얻은 땅

    public Claim(UUID id, String world, int ax, int az, int bx, int bz, UUID owner, UUID nation, boolean annexed) {
        this.id = id;
        this.world = world;
        this.x1 = Math.min(ax, bx);
        this.x2 = Math.max(ax, bx);
        this.z1 = Math.min(az, bz);
        this.z2 = Math.max(az, bz);
        this.owner = owner;
        this.nation = nation;
        this.annexed = annexed;
    }

    public boolean contains(int x, int z) { return x >= x1 && x <= x2 && z >= z1 && z <= z2; }

    public boolean intersects(int ax1, int az1, int ax2, int az2) {
        return !(ax2 < x1 || ax1 > x2 || az2 < z1 || az1 > z2);
    }

    public long area() { return (long) (x2 - x1 + 1) * (z2 - z1 + 1); }

    public int centerX() { return (x1 + x2) >> 1; }

    public int centerZ() { return (z1 + z2) >> 1; }

    /** 점에서 이 땅까지의 거리(블록). 안에 있으면 0 */
    public double distanceTo(double x, double z) {
        double dx = Math.max(Math.max(x1 - x, 0), x - (x2 + 1));
        double dz = Math.max(Math.max(z1 - z, 0), z - (z2 + 1));
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** 다른 직사각형과의 간격(블록, 맞닿으면 0) */
    public int gapTo(int ax1, int az1, int ax2, int az2) {
        int dx = Math.max(0, Math.max(x1 - ax2, ax1 - x2) - 1);
        int dz = Math.max(0, Math.max(z1 - az2, az1 - z2) - 1);
        return Math.max(dx, dz);
    }

    public String coord() { return "(" + x1 + ", " + z1 + ") ~ (" + x2 + ", " + z2 + ")"; }
}
