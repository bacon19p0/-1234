package com.nationwar;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/** 모든 창(GUI)의 공통 홀더. 상자 창이지만 아이템은 가져갈 수 없고, 클릭하면 그 항목이 선택된다. */
public final class MenuHolder implements InventoryHolder {
    public final Inventory inv;
    public final int rows;
    /** 좌클릭만 인정하는 동작 */
    public final Map<Integer, Consumer<Player>> actions = new HashMap<>();
    /** 좌클릭/우클릭을 구분하는 동작 (상점 등) */
    public final Map<Integer, BiConsumer<Player, ClickType>> clickActions = new HashMap<>();
    public Runnable onClose;
    public String tag;

    public MenuHolder(String title, int rows) {
        this.rows = rows;
        this.inv = Bukkit.createInventory(this, rows * 9, Msg.c(title));
    }

    public MenuHolder set(int slot, ItemStack item, Consumer<Player> action) {
        inv.setItem(slot, item);
        if (action != null) actions.put(slot, action);
        return this;
    }

    public MenuHolder setClick(int slot, ItemStack item, BiConsumer<Player, ClickType> action) {
        inv.setItem(slot, item);
        if (action != null) clickActions.put(slot, action);
        return this;
    }

    public void clear() {
        inv.clear();
        actions.clear();
        clickActions.clear();
    }

    public void clearAll() { clear(); }

    @Override
    public Inventory getInventory() { return inv; }
}
