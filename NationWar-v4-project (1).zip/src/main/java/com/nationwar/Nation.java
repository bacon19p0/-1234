package com.nationwar;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

public final class Nation {
    public final UUID id;
    public String name;
    public UUID leader;                    // 땅 주인(건국자) = 최고인
    public UUID capitalClaim;              // 수도 땅 (자석석은 이 땅 안에만 있음)
    public String magnetWorld;
    public int mx, my, mz;
    public final Set<UUID> members = new LinkedHashSet<>();
    public UUID overlordNation;            // 식민지라면 종주국 id
    public UUID overlordPlayer;            // 식민지로 만든 플레이어
    public long lockUntil;                 // 식민지 변경 불가 해제 시각(ms)
    public boolean rebelling;              // 반란 진행 중
    public UUID magnetCarrier;             // 자석석을 들고 있는 사람(옮기는 중이면 non-null)

    public Nation(UUID id, String name, UUID leader) {
        this.id = id;
        this.name = name;
        this.leader = leader;
        this.members.add(leader);
    }

    public boolean isColony() { return overlordNation != null; }
}
