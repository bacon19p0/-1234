package com.nationwar;

import java.util.UUID;

public final class War {
    public final UUID declarer;
    public final UUID target;
    public final long since;

    public War(UUID declarer, UUID target, long since) {
        this.declarer = declarer;
        this.target = target;
        this.since = since;
    }

    public static String key(UUID a, UUID b) {
        return a.compareTo(b) < 0 ? a + "_" + b : b + "_" + a;
    }

    public boolean involves(UUID n) { return declarer.equals(n) || target.equals(n); }

    public UUID other(UUID n) { return declarer.equals(n) ? target : declarer; }
}
