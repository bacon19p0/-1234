package com.nationwar;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.ToolComponent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

public final class Items {
    private static NamespacedKey FLAG, MONEY, LAND, PICK, INVSAVE, INSURE, MAGNET;

    private Items() {}

    public static void init(Plugin plugin) {
        FLAG = new NamespacedKey(plugin, "flag");
        MONEY = new NamespacedKey(plugin, "money");
        LAND = new NamespacedKey(plugin, "landtool");
        PICK = new NamespacedKey(plugin, "magnetpick");
        INSURE = new NamespacedKey(plugin, "insurance");
        MAGNET = new NamespacedKey(plugin, "magnetitem");
        INVSAVE = new NamespacedKey(plugin, "invsave");
    }

    // ---------- 공통 아이콘 (GUI용) ----------
    public static ItemStack icon(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(Msg.item(s));
        meta.lore(l);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    public static ItemStack icon(Material m, String name, String... lore) {
        return icon(m, name, Arrays.asList(lore));
    }

    /** 원래 아이템 이름 그대로, 설명만 붙임 */
    public static ItemStack sellIcon(Material m, List<String> lore) {
        return loreOn(new ItemStack(m), lore);
    }

    /** 아이템 복사본에 설명 줄을 덧붙임 (기존 설명 유지) */
    public static ItemStack loreOn(ItemStack base, List<String> extra) {
        ItemStack it = base.clone();
        ItemMeta meta = it.getItemMeta();
        List<Component> l = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String s : extra) l.add(Msg.item(s));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    // ---------- 저장용 직렬화 ----------
    public static String serialize(ItemStack it) {
        return Base64.getEncoder().encodeToString(it.serializeAsBytes());
    }

    public static ItemStack deserialize(String s) {
        try {
            return ItemStack.deserializeBytes(Base64.getDecoder().decode(s));
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- 선전포고 깃발 ----------
    public static ItemStack warFlag() {
        ItemStack it = new ItemStack(Material.RED_BANNER);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<red><bold>선전포고 깃발"));
        meta.lore(List.of(Msg.item("<gray>타국 영토 근처에서 우클릭: 선전포고")));
        meta.getPersistentDataContainer().set(FLAG, PersistentDataType.STRING, "war");
        it.setItemMeta(meta);
        return it;
    }

    public static String flagType(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(FLAG, PersistentDataType.STRING);
    }

    // ---------- 돈 (종이 수표: 이름 없음, 리소스팩 모델 + 서바이벌에서 불가능한 인챈트) ----------
    public static ItemStack moneyNote(long value) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta meta = it.getItemMeta();
        NamespacedKey model = NamespacedKey.fromString("nationwar:money");
        if (model != null) meta.setItemModel(model);
        meta.addEnchant(Enchantment.SHARPNESS, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.lore(List.of(Msg.item("<gray>" + NationManager.fmt(value))));
        meta.getPersistentDataContainer().set(MONEY, PersistentDataType.LONG, value);
        it.setItemMeta(meta);
        return it;
    }

    public static long noteValue(ItemStack it) {
        if (it == null || it.getType() != Material.PAPER || !it.hasItemMeta()) return 0;
        Long v = it.getItemMeta().getPersistentDataContainer().get(MONEY, PersistentDataType.LONG);
        return v == null ? 0 : v;
    }

    // ---------- 인벤세이브 종이 (1장 = 죽을 때 1번 인벤토리 보존) ----------
    public static ItemStack invSavePaper() {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<aqua><bold>인벤세이브 종이"));
        meta.lore(List.of(Msg.item("<gray>가지고 있으면 죽을 때 인벤토리를 1번 지켜줍니다."), Msg.item("<gray>(1장 소모)")));
        meta.getPersistentDataContainer().set(INVSAVE, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    public static boolean isInvSave(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(INVSAVE, PersistentDataType.BYTE);
    }

    // ---------- 땅 선택 금 괭이 ----------
    public static ItemStack landTool() {
        ItemStack it = new ItemStack(Material.GOLDEN_HOE);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<gold><bold>땅 선택 괭이"));
        meta.lore(List.of(
                Msg.item("<gray>블록 우클릭: 첫 번째 지점"),
                Msg.item("<gray>다른 블록 좌클릭: 두 번째 지점"),
                Msg.item("<gray>두 지점 사이 직사각형(위에서 본 1칸당 가격)을 구매합니다")));
        meta.setUnbreakable(true);
        meta.getPersistentDataContainer().set(LAND, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    public static boolean isLandTool(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(LAND, PersistentDataType.BYTE);
    }

    // ---------- 자석석 곡괭이 (자석석만 캘 수 있음) ----------
    public static ItemStack magnetPick(double seconds) {
        ItemStack it = new ItemStack(Material.IRON_PICKAXE);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<gold><bold>자석석 곡괭이"));
        meta.lore(List.of(Msg.item("<gray>자석석만 캘 수 있습니다 (약 " + (int) seconds + "초)")));
        meta.setUnbreakable(true);
        ToolComponent tool = meta.getTool();
        tool.setDefaultMiningSpeed(1.0f);
        tool.setDamagePerBlock(0);
        // 자석석 경도 3.5 -> 시간(초) = 3.5*1.5/속도
        tool.addRule(Material.LODESTONE, (float) (3.5 * 1.5 / Math.max(0.1, seconds)), true);
        meta.setTool(tool);
        meta.getPersistentDataContainer().set(PICK, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    public static ItemStack magnetPick() { return magnetPick(5); }

    public static boolean isMagnetPick(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(PICK, PersistentDataType.BYTE);
    }

    // ---------- 혁명군 지급품 ----------
    public static List<ItemStack> rebelKit() {
        ItemStack sword = new ItemStack(Material.IRON_SWORD);
        ItemMeta sm = sword.getItemMeta();
        sm.addEnchant(Enchantment.SHARPNESS, 2, true);
        sword.setItemMeta(sm);
        return List.of(new ItemStack(Material.DIAMOND_HELMET), new ItemStack(Material.DIAMOND_CHESTPLATE),
                new ItemStack(Material.DIAMOND_LEGGINGS), new ItemStack(Material.DIAMOND_BOOTS), sword);
    }

    // ---------- 좌표 종이 ----------
    public static ItemStack coordPaper(Nation n, List<Claim> lands) {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<red>땅 좌표"));
        List<Component> lore = new ArrayList<>();
        lore.add(Msg.item("<gray>국가: <white>" + Msg.esc(n.name)));
        int shown = 0;
        for (Claim c : lands) {
            if (shown++ >= 8) { lore.add(Msg.item("<gray>...")); break; }
            lore.add(Msg.item("<yellow>" + c.world + " <white>" + c.coord()));
        }
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }
    // ---------- 인벤세이브 종이 ----------
    public static ItemStack insurancePaper() {
        ItemStack it = new ItemStack(Material.PAPER);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<aqua><bold>인벤세이브 종이"));
        meta.lore(List.of(Msg.item("<gray>인벤토리에 가지고 있으면 사망 시"), Msg.item("<gray>1장을 소모하고 인벤토리를 보존합니다.")));
        meta.getPersistentDataContainer().set(INSURE, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    public static boolean isInsurance(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(INSURE, PersistentDataType.BYTE);
    }

    // ---------- 들고 다니는 자석석 ----------
    public static ItemStack magnetItem(Nation n) {
        ItemStack it = new ItemStack(Material.LODESTONE);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.item("<gold><bold>자석석 <gray>(" + Msg.esc(n.name) + ")"));
        meta.lore(List.of(Msg.item("<gray>자기 땅 안에 설치하세요. (Y 범위 제한)"), Msg.item("<red>설치 전에는 자기 땅 밖으로 나갈 수 없습니다.")));
        meta.getPersistentDataContainer().set(MAGNET, PersistentDataType.STRING, n.id.toString());
        it.setItemMeta(meta);
        return it;
    }

    public static boolean isMagnetItem(ItemStack it) { return magnetNation(it) != null; }

    public static java.util.UUID magnetNation(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String v = it.getItemMeta().getPersistentDataContainer().get(MAGNET, PersistentDataType.STRING);
        if (v == null) return null;
        try {
            return java.util.UUID.fromString(v);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    // ---------- 원래 설명 뒤에 줄 추가 ----------
    public static ItemStack withLore(ItemStack base, List<String> extra) {
        ItemStack it = base.clone();
        ItemMeta meta = it.getItemMeta();
        List<Component> l = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String s : extra) l.add(Msg.item(s));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }
}
