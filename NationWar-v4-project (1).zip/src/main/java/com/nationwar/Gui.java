package com.nationwar;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;

/**
 * 모든 창(GUI). 상자 창과 같지만 아이템은 가져갈 수 없고, 아이템(블록)을 클릭하면 그 항목이 선택된다.
 * 모든 창 맨 아래 줄: [이전 페이지] ... [뒤로가기/닫기] ... [다음 페이지]
 */
public final class Gui {
    private static final int PAGE = 36;

    private final NationWarPlugin plugin;
    private final NationManager m;
    private final Set<UUID> invulnerable = new HashSet<>();
    private final Map<UUID, BiFunction<Player, String, Boolean>> prompts = new HashMap<>();
    private final Map<UUID, Long> passCooldown = new HashMap<>();

    private record Entry(ItemStack icon, BiConsumer<Player, ClickType> action) {}

    public Gui(NationWarPlugin plugin, NationManager m) {
        this.plugin = plugin;
        this.m = m;
    }

    public boolean isInvulnerable(UUID u) { return invulnerable.contains(u); }

    public boolean hasPrompt(UUID u) { return prompts.containsKey(u); }

    public void onQuit(UUID u) {
        invulnerable.remove(u);
        prompts.remove(u);
    }

    private void result(Player p, String err, String ok) {
        if (err != null) Msg.send(p, "<red>" + err);
        else if (ok != null) Msg.send(p, "<green>" + ok);
    }

    private void bar(Player p, String mm) { p.sendActionBar(Msg.c(mm)); }

    private void pane(MenuHolder h, int from, int to) {
        for (int i = from; i <= to; i++) h.set(i, Items.icon(Material.GRAY_STAINED_GLASS_PANE, " "), null);
    }

    /** 맨 아래 줄: 이전 페이지 / 뒤로가기(없으면 닫기) / 다음 페이지 */
    private void nav(MenuHolder h, Consumer<Player> back, int page, int pages, Consumer<Integer> go) {
        int base = (h.rows - 1) * 9;
        pane(h, base, base + 8);
        if (page > 0) {
            h.set(base, Items.icon(Material.ARROW, "<yellow>◀ 이전 페이지", "<gray>" + page + " / " + pages), pl -> go.accept(page - 1));
        } else {
            h.set(base, Items.icon(Material.GRAY_DYE, "<gray>◀ 첫 페이지"), null);
        }
        if (back != null) h.set(base + 4, Items.icon(Material.SPECTRAL_ARROW, "<yellow>뒤로가기"), back);
        else h.set(base + 4, Items.icon(Material.BARRIER, "<red>닫기"), Player::closeInventory);
        if (page < pages - 1) {
            h.set(base + 8, Items.icon(Material.ARROW, "<yellow>다음 페이지 ▶", "<gray>" + (page + 2) + " / " + pages), pl -> go.accept(page + 1));
        } else {
            h.set(base + 8, Items.icon(Material.GRAY_DYE, "<gray>마지막 페이지 ▶"), null);
        }
    }

    private void nav(MenuHolder h, Consumer<Player> back) { nav(h, back, 0, 1, x -> { }); }

    // ===================== 채팅 입력 =====================
    /** handler가 true를 반환하면 입력 종료, false면 다시 입력 받음 */
    private void startPrompt(Player p, List<String> redLines, BiFunction<Player, String, Boolean> handler) {
        p.closeInventory();
        prompts.put(p.getUniqueId(), handler);
        for (String l : redLines) p.sendMessage(Msg.c("<red>" + l));
    }

    public void handleChat(Player p, String text) {
        BiFunction<Player, String, Boolean> fn = prompts.get(p.getUniqueId());
        if (fn == null) return;
        boolean done = fn.apply(p, text.trim());
        if (done && prompts.get(p.getUniqueId()) == fn) prompts.remove(p.getUniqueId());
    }

    /** 금액을 채팅으로 입력받는 공통 처리 */
    private void askAmount(Player p, String verb, long max, BiFunction<Player, Long, String> apply, Consumer<Player> after) {
        startPrompt(p, List.of(
                verb + "할 금액을 채팅으로 입력하세요.",
                "숫자만 입력하세요. (1원 ~ " + NationManager.fmt(max) + ")",
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (text.equals("취소")) {
                pl.sendMessage(Msg.c("<red>" + verb + "이(가) 취소되었습니다."));
                after.accept(pl);
                return true;
            }
            long v;
            try {
                v = Long.parseLong(text);
            } catch (NumberFormatException ex) {
                pl.sendMessage(Msg.c("<red>숫자만 입력하세요. (취소하려면 '취소')"));
                return false;
            }
            if (v < 1 || v > max) {
                pl.sendMessage(Msg.c("<red>1원 ~ " + NationManager.fmt(max) + " 사이로 입력하세요."));
                return false;
            }
            String err = apply.apply(pl, v);
            if (err != null) pl.sendMessage(Msg.c("<red>" + err));
            else pl.sendMessage(Msg.c("<green>" + NationManager.fmt(v) + " " + verb + " 완료!"));
            after.accept(pl);
            return true;
        });
    }

    // ===================== 상태창 (Shift + F) =====================
    public void openStatus(Player p) {
        Nation n = m.nationOf(p.getUniqueId());
        MenuHolder h = new MenuHolder("<dark_green>상태창", 3);
        if (n != null && n.isColony()) {
            h.set(10, Items.icon(Material.GRASS_BLOCK, "<red>혁명",
                    "<gray>식민지 시민은 땅 관리를 할 수 없습니다.", "<red>클릭: 반란을 시작합니다!"), pl -> {
                pl.closeInventory();
                String err = m.startRebellion(pl);
                if (err != null) Msg.send(pl, "<red>" + err);
            });
        } else {
            h.set(10, Items.icon(Material.GRASS_BLOCK, "<green>땅 관리",
                    "<gray>내 땅, 통행료, 금 괭이, 선전포고 깃발,", "<gray>건국, 자석석 이동, 경계선, 탈퇴"), this::openLand);
        }
        h.set(12, Items.icon(Material.GOLD_INGOT, "<gold>은행",
                "<gray>잔액: <white>" + NationManager.fmt(m.balance(p.getUniqueId())), "<gray>입금 / 출금"), this::openBank);
        h.set(14, Items.icon(Material.CHEST, "<aqua>상점", "<gray>상품 구매 / 상품 판매 / 유저 상점"), pl -> openShop(pl, 0, 0));
        nav(h, null);
        p.openInventory(h.inv);
    }

    // ===================== 땅 관리 =====================
    public void openLand(Player p) {
        UUID u = p.getUniqueId();
        Nation n = m.nationOf(u);
        MenuHolder h = new MenuHolder("<dark_green>땅 관리", 4);
        h.set(10, Items.icon(Material.MAP, "<green>내 땅 좌표", m.landLines(u)), null);
        h.set(11, Items.icon(Material.OAK_SIGN, "<gold>통행료 설정",
                "<gray>현재 통행료: <white>" + NationManager.fmt(m.toll.getOrDefault(u, plugin.getConfig().getInt("pass.default-toll", 0))),
                "<gray>0원 = 무료, 1원 ~ 10000원", "<yellow>클릭: 채팅으로 입력"), pl -> {
            if (!m.ownsLand(pl.getUniqueId())) { Msg.send(pl, "<red>땅 주인만 통행료를 설정할 수 있습니다."); return; }
            startTollPrompt(pl);
        });
        h.set(12, Items.icon(Material.GOLDEN_HOE, "<gold>금 괭이 받기", "<gray>인벤토리에 없을 때 지급"), pl ->
                result(pl, m.giveLandTool(pl), "땅 선택 괭이를 받았습니다."));
        h.set(13, Items.icon(Material.RED_BANNER, "<red>선전포고 깃발 받기",
                "<gray>인벤토리(셜커 상자 포함)에 없을 때 1개 지급", "<gray>타국 땅 근처에서 우클릭하면 선전포고"), pl ->
                result(pl, m.giveWarFlag(pl), "선전포고 깃발을 받았습니다."));
        if (n == null) {
            h.set(14, Items.icon(Material.WHITE_BANNER, "<aqua>건국",
                    "<gray>금 괭이로 고른 범위로 국가를 세웁니다.", "<gray>(블록 우클릭 → 다른 블록 좌클릭 후 사용)"), pl -> {
                NationManager.Plan pln = m.plan(pl, true);
                if (pln.error() != null) { Msg.send(pl, "<red>" + pln.error()); return; }
                startFoundPrompt(pl, pln);
            });
        }
        if (!m.colonies(u).isEmpty()) {
            List<String> lore = new ArrayList<>();
            for (Nation col : m.colonies(u)) lore.add("<white>" + Msg.esc(col.name) + " <gray>(시민 " + col.members.size() + "명)");
            lore.add("<yellow>클릭: 식민지 관리");
            h.set(15, Items.icon(Material.RED_BANNER, "<red>식민지 땅", lore), this::openColonies);
        }
        boolean on = m.isBorderOn(u);
        h.set(16, Items.icon(on ? Material.LIME_DYE : Material.GRAY_DYE, on ? "<green>경계선 표시: 켜짐" : "<gray>경계선 표시: 꺼짐",
                "<gray>내 땅 가장자리의 초록 선", "<yellow>클릭: " + (on ? "끄기" : "켜기")), pl -> {
            m.toggleBorder(pl.getUniqueId());
            openLand(pl);
        });
        if (n != null && n.leader.equals(u)) {
            h.set(19, Items.icon(Material.LODESTONE, "<gold>자석석 옮기기",
                    "<gray>자석석이 인벤토리로 들어옵니다.",
                    "<gray>자기 땅 안, Y " + plugin.getConfig().getInt("magnet.min-y", -20) + " ~ " + plugin.getConfig().getInt("magnet.max-y", 200) + " 에 설치하세요.",
                    "<red>설치 전에는 자기 땅 밖으로 나갈 수 없습니다.", "<gray>(전쟁 중 불가)"), pl -> {
                pl.closeInventory();
                result(pl, m.moveMagnet(pl), "자석석을 가져왔습니다. 자기 땅 안에 설치하세요.");
            });
            h.set(20, Items.icon(Material.EMERALD, "<green>시민 추가", "<gray>플레이어를 국가에 초대합니다.", "<yellow>클릭: 닉네임을 채팅으로 입력/선택"), pl -> startInvitePrompt(pl));
            h.set(21, Items.icon(Material.PLAYER_HEAD, "<red>시민 제거", "<gray>시민을 국가에서 추방합니다.", "<yellow>클릭: 시민 목록"), this::openMembers);
        }
        if (n != null) {
            final boolean lead = n.leader.equals(u);
            h.set(25, Items.icon(Material.BARRIER, lead ? "<red>국가 해체 (탈퇴)" : "<red>국가 탈퇴",
                    lead ? "<gray>땅 주인은 탈퇴 대신 국가를 해체합니다." : "<gray>소유한 땅을 모두 버리고 떠납니다."), pl ->
                    openConfirm(pl, lead ? "<dark_red>국가 해체" : "<dark_red>국가 탈퇴", "<gray>정말 진행하시겠습니까? 되돌릴 수 없습니다.", () ->
                            result(pl, lead ? m.disband(pl) : m.leave(pl), lead ? "국가를 해체했습니다." : "국가를 떠났습니다."), this::openLand));
        }
        nav(h, this::openStatus);
        p.openInventory(h.inv);
    }

    private void startTollPrompt(Player p) {
        startPrompt(p, List.of(
                "통행료를 채팅으로 입력하세요.",
                "숫자만 입력하세요. (0 = 무료, 1원 ~ 10000원)",
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (text.equals("취소")) { pl.sendMessage(Msg.c("<red>통행료 설정이 취소되었습니다.")); return true; }
            long v;
            try {
                v = Long.parseLong(text);
            } catch (NumberFormatException ex) {
                pl.sendMessage(Msg.c("<red>숫자만 입력하세요. (0 = 무료, 1~10000, 취소하려면 '취소')"));
                return false;
            }
            if (v < 0 || v > 10_000) {
                pl.sendMessage(Msg.c("<red>통행료는 0원(무료) 또는 1원~10000원까지만 가능합니다. 10000원을 넘을 수 없습니다. 다시 입력하세요."));
                return false;
            }
            String err = m.setToll(pl, (int) v);
            if (err != null) pl.sendMessage(Msg.c("<red>" + err));
            else pl.sendMessage(Msg.c(v == 0 ? "<red>통행료를 무료(0원)로 설정했습니다." : "<red>통행료를 " + NationManager.fmt(v) + " 으로 설정했습니다."));
            return true;
        });
    }

    private void startFoundPrompt(Player p, NationManager.Plan pln) {
        startPrompt(p, List.of(
                "국가 이름을 채팅으로 입력하세요. (한글/영문/숫자/_ 2~12자)",
                "선택한 땅: " + String.format("%,d", pln.area()) + "블록 / 가격 " + NationManager.fmt(pln.price()),
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (text.equals("취소")) { pl.sendMessage(Msg.c("<red>건국이 취소되었습니다.")); return true; }
            String nameErr = m.checkName(text);
            if (nameErr != null) { pl.sendMessage(Msg.c("<red>" + nameErr + " 다시 입력하세요.")); return false; }
            String err = m.createNation(pl, text);
            if (err != null) pl.sendMessage(Msg.c("<red>" + err));
            else Msg.send(pl, "<green>건국했습니다! 수도에 자석석이 생성되었습니다.");
            return true;
        });
    }

    // ===================== 은행 (금액을 채팅으로 입력) =====================
    public void openBank(Player p) {
        UUID u = p.getUniqueId();
        MenuHolder h = new MenuHolder("<gold>은행", 4);
        h.set(4, Items.icon(Material.GOLD_INGOT, "<gold>은행",
                "<gray>잔액: <white>" + NationManager.fmt(m.balance(u)), "<gray>빚: <white>" + NationManager.fmt(m.debt(u))), null);
        h.set(11, Items.icon(Material.EMERALD, "<green>입금", "<gray>인벤토리의 종이 수표에서 입금합니다.", "<yellow>클릭: 금액을 채팅으로 입력"), pl ->
                askAmount(pl, "입금", 1_000_000_000L, (pp, v) -> m.depositAmount(pp, v), this::openBank));
        h.set(13, Items.icon(Material.PLAYER_HEAD, "<aqua>송금", "<gray>다른 플레이어에게 돈을 보냅니다.", "<yellow>클릭: 받을 플레이어를 채팅으로 선택"), this::startTransfer);
        h.set(15, Items.icon(Material.PAPER, "<yellow>출금", "<gray>잔액을 종이 수표 1장으로 출금합니다.", "<yellow>클릭: 금액을 채팅으로 입력"), pl ->
                askAmount(pl, "출금", Math.max(1, m.balance(pl.getUniqueId())), (pp, v) -> m.withdraw(pp, v), this::openBank));
        h.set(22, Items.icon(Material.BOOK, "<gold>대출", "<gray>대출 받기 / 상환", "<gray>현재 빚: " + NationManager.fmt(m.debt(u))), this::openLoan);
        nav(h, this::openStatus);
        p.openInventory(h.inv);
    }

    public void openLoan(Player p) {
        UUID u = p.getUniqueId();
        MenuHolder h = new MenuHolder("<gold>대출", 4);
        final long left = Math.max(0, m.maxLoan() - m.debt(u));
        h.set(4, Items.icon(Material.BOOK, "<gold>대출 현황",
                "<gray>현재 빚(이자 포함): <white>" + NationManager.fmt(m.debt(u)),
                "<gray>최대 한도: <white>" + NationManager.fmt(m.maxLoan()),
                "<gray>남은 한도: <white>" + NationManager.fmt(left),
                "<gray>이자: " + plugin.getConfig().getDouble("bank.loan-interest-percent", 10) + "% (대출 시 1회)"), null);
        h.set(11, Items.icon(Material.EMERALD, "<green>대출 받기", "<yellow>클릭: 받을 금액을 채팅으로 입력"), pl ->
                askAmount(pl, "대출", Math.max(1, left), (pp, v) -> m.borrow(pp, v), this::openLoan));
        h.set(15, Items.icon(Material.GOLD_INGOT, "<yellow>상환", "<yellow>클릭: 갚을 금액을 채팅으로 입력"), pl ->
                askAmount(pl, "상환", Math.max(1, m.debt(pl.getUniqueId())), (pp, v) -> m.repay(pp, v), this::openLoan));
        nav(h, this::openBank);
        p.openInventory(h.inv);
    }

    /** 송금: 채팅에 닉네임이 뜨고(클릭 가능) 선택하면 금액을 입력 */
    private void startTransfer(Player p) {
        Component names = Msg.c("<yellow>송금할 플레이어 (클릭): ");
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.getUniqueId().equals(p.getUniqueId())) continue;
            names = names.append(Component.text(o.getName() + " ", NamedTextColor.GREEN)
                    .clickEvent(ClickEvent.runCommand("/국가 송금선택 " + o.getName())));
        }
        startPrompt(p, List.of("송금할 플레이어를 선택하세요. 아래 닉네임을 클릭하거나 직접 입력하세요.",
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (text.equals("취소")) { pl.sendMessage(Msg.c("<red>송금이 취소되었습니다.")); openBank(pl); return true; }
            OfflinePlayer t = Bukkit.getPlayerExact(text);
            if (t == null) t = Bukkit.getOfflinePlayer(text);
            if (!t.isOnline() && !t.hasPlayedBefore()) { pl.sendMessage(Msg.c("<red>그런 플레이어를 찾을 수 없습니다. 다시 입력하세요.")); return false; }
            if (t.getUniqueId().equals(pl.getUniqueId())) { pl.sendMessage(Msg.c("<red>자기 자신에게는 송금할 수 없습니다.")); return false; }
            final UUID tid = t.getUniqueId();
            final String tname = t.getName() == null ? text : t.getName();
            pl.sendMessage(Msg.c("<red>" + Msg.esc(tname) + " 님에게 송금합니다."));
            askAmount(pl, "송금", Math.max(1, m.balance(pl.getUniqueId())), (pp, v) -> m.transfer(pp, tid, v), this::openBank);
            return true;
        });
        p.sendMessage(names);
    }

    // ===================== 상점 (상품 구매 | 상품 판매 | 유저 상점) =====================
    // 창을 닫지 않고 그 자리에서 갱신한다. 판매/구매: 좌클릭=1개, 우클릭=전체
    public void openShop(Player p, int tab, int page) {
        MenuHolder h = new MenuHolder("<aqua>상점", 6);
        renderShop(h, p, tab, page);
        p.openInventory(h.inv);
    }

    private void renderShop(MenuHolder h, Player p, int tab, int page) {
        final int[] cur = {page};
        h.clearAll();
        pane(h, 0, 8);
        h.set(0, Items.icon(Material.GOLD_INGOT, "<gold>잔액", "<white>" + NationManager.fmt(m.balance(p.getUniqueId()))), null);
        h.set(2, Items.icon(Material.CHEST, "<green>상품 구매", tab == 0 ? "<yellow>▶ 현재 보기" : "<gray>클릭: 보기"), pl -> renderShop(h, pl, 0, 0));
        h.set(4, Items.icon(Material.GOLD_BLOCK, "<gold>상품 판매", tab == 1 ? "<yellow>▶ 현재 보기" : "<gray>클릭: 보기"), pl -> renderShop(h, pl, 1, 0));
        h.set(8, Items.icon(Material.EMERALD_BLOCK, "<aqua>유저 상점", tab == 2 ? "<yellow>▶ 현재 보기" : "<gray>클릭: 보기"), pl -> renderShop(h, pl, 2, 0));

        List<Entry> entries;
        if (tab == 0) entries = buyEntries(h, p, cur);
        else if (tab == 1) entries = sellEntries(h, p, cur);
        else entries = userEntries(h, p, cur);

        if (tab == 1) {
            h.set(6, Items.icon(Material.HOPPER, "<green>모두 판매", "<gray>인벤토리의 판매 가능한 아이템을", "<gray>전부 한 번에 판매합니다."), pl -> {
                long earned = m.sellEverything(pl);
                if (earned <= 0) bar(pl, "<red>판매할 아이템이 없습니다.");
                else bar(pl, "<green>+" + NationManager.fmt(earned));
                renderShop(h, pl, 1, cur[0]);
            });
        }

        int pages = Math.max(1, (entries.size() + PAGE - 1) / PAGE);
        cur[0] = Math.max(0, Math.min(cur[0], pages - 1));
        for (int i = 0; i < PAGE; i++) {
            int idx = cur[0] * PAGE + i;
            if (idx >= entries.size()) break;
            Entry e = entries.get(idx);
            h.setClick(9 + i, e.icon(), e.action());
        }
        if (tab == 2) userBar(h, p, cur[0], pages, np -> renderShop(h, p, tab, np));
        else nav(h, this::openStatus, cur[0], pages, np -> renderShop(h, p, tab, np));
    }

    private List<Entry> buyEntries(MenuHolder h, Player p, int[] cur) {
        List<Entry> l = new ArrayList<>();

        long pick = plugin.getConfig().getLong("shop.magnet-pickaxe-price", 2000);
        l.add(new Entry(Items.icon(Material.IRON_PICKAXE, "<gold>자석석 곡괭이",
                "<gray>자석석을 " + plugin.getConfig().getInt("magnet.pick-break-seconds", 5) + "초 만에 캡니다.",
                "<gray>(다른 도구/맨손은 " + plugin.getConfig().getInt("magnet.break-seconds", 10) + "초)",
                "<gray>자석석 외에는 캘 수 없습니다.", "<yellow>가격: " + NationManager.fmt(pick), "<green>좌클릭: 구매"), (pl, ct) -> {
            if (!ct.isLeftClick()) return;
            if (!m.charge(pl.getUniqueId(), pick)) { bar(pl, "<red>잔액이 부족합니다."); return; }
            m.giveItem(pl, Items.magnetPick());
            bar(pl, "<green>자석석 곡괭이를 구매했습니다.");
            renderShop(h, pl, 0, cur[0]);
        }));

        long inv = plugin.getConfig().getLong("shop.invsave-price", 1000);
        l.add(new Entry(Items.loreOn(Items.invSavePaper(), List.of("<yellow>가격: " + NationManager.fmt(inv), "<green>좌클릭: 구매")), (pl, ct) -> {
            if (!ct.isLeftClick()) return;
            if (!m.charge(pl.getUniqueId(), inv)) { bar(pl, "<red>잔액이 부족합니다."); return; }
            m.giveItem(pl, Items.invSavePaper());
            bar(pl, "<green>인벤세이브 종이를 구매했습니다.");
            renderShop(h, pl, 0, cur[0]);
        }));

        for (int i = 0; i < m.shopItems.size(); i++) {
            final int index = i;
            NationManager.ShopItem si = m.shopItems.get(i);
            List<String> lore = new ArrayList<>();
            lore.add("<yellow>가격: " + NationManager.fmt(si.price()));
            lore.add("<green>좌클릭: 구매");
            if (p.hasPermission("nationwar.admin")) lore.add("<dark_gray>관리자: 삭제 /국가관리 상점삭제 " + (i + 1));
            l.add(new Entry(Items.loreOn(si.item(), lore), (pl, ct) -> {
                if (!ct.isLeftClick()) return;
                String err = m.buyShopItem(pl, index);
                if (err != null) bar(pl, "<red>" + err); else bar(pl, "<green>구매했습니다.");
                renderShop(h, pl, 0, cur[0]);
            }));
        }

        // 광석 상점 (구워진 것만, 서버 공용 재고)
        for (NationManager.OreInfo o : m.oreInfos()) {
            int stock = m.oreStockOf(o.mat());
            long left = m.oreSecondsLeft();
            List<String> lore = new ArrayList<>();
            lore.add("<yellow>가격: " + NationManager.fmt(o.price()) + " (1개)");
            lore.add(stock > 0 ? "<gray>재고: <white>" + stock + "개" : "<red><bold>매진");
            lore.add("<gray>재고 리셋까지: " + (left / 60) + "분 " + (left % 60) + "초");
            if (stock > 0) { lore.add("<green>좌클릭: 1개 구매"); lore.add("<green>우클릭: 전부 구매"); }
            final Material mat = o.mat();
            l.add(new Entry(Items.sellIcon(mat, lore), (pl, ct) -> {
                if (!ct.isLeftClick() && !ct.isRightClick()) return;
                String err = m.buyOre(pl, mat, ct.isRightClick());
                if (err != null) bar(pl, "<red>" + err); else bar(pl, "<green>구매했습니다.");
                renderShop(h, pl, 0, cur[0]);
            }));
        }
        return l;
    }

    private List<Entry> sellEntries(MenuHolder h, Player p, int[] cur) {
        List<Entry> l = new ArrayList<>();
        for (Map.Entry<Material, Long> e : m.sellPrices().entrySet()) {
            final Material mat = e.getKey();
            final long price = e.getValue();
            int have = m.countPlain(p, mat);
            l.add(new Entry(Items.sellIcon(mat, List.of(
                    "<yellow>판매가: " + NationManager.fmt(price) + " (1개)",
                    "<gray>보유: " + have + "개",
                    "<green>좌클릭: 1개 판매",
                    "<green>우클릭: 전체 판매" + (have > 0 ? " (" + NationManager.fmt(price * have) + ")" : ""))), (pl, ct) -> {
                long earned;
                if (ct.isRightClick()) earned = m.sellAll(pl, mat);
                else if (ct.isLeftClick()) earned = m.sellOne(pl, mat);
                else return;
                if (earned <= 0) bar(pl, "<red>판매할 아이템이 없습니다.");
                else bar(pl, "<green>+" + NationManager.fmt(earned));
                renderShop(h, pl, 1, cur[0]);
            }));
        }
        return l;
    }

    private List<Entry> userEntries(MenuHolder h, Player p, int[] cur) {
        List<Entry> l = new ArrayList<>();
        for (NationManager.Listing li : m.listings) {
            final boolean mine = li.seller().equals(p.getUniqueId());
            List<String> lore = new ArrayList<>();
            lore.add("<gray>판매자: <white>" + Msg.esc(li.sellerName()));
            lore.add("<yellow>가격: " + NationManager.fmt(li.price()));
            if (mine) lore.add("<aqua>내 물건 - 좌클릭: 회수");
            else { lore.add("<green>좌클릭: 바로 구매"); lore.add("<gold>우클릭: 네고 (가격 흥정)"); }
            final UUID id = li.id();
            l.add(new Entry(Items.loreOn(li.item(), lore), (pl, ct) -> {
                if (mine) {
                    if (!ct.isLeftClick()) return;
                    String err = m.cancelListing(pl, id);
                    bar(pl, err != null ? "<red>" + err : "<green>회수했습니다.");
                } else if (ct.isRightClick()) {
                    startNegotiation(pl, id);
                    return;
                } else if (ct.isLeftClick()) {
                    String err = m.buyListing(pl, id);
                    bar(pl, err != null ? "<red>" + err : "<green>구매했습니다.");
                } else {
                    return;
                }
                renderShop(h, pl, 2, cur[0]);
            }));
        }
        return l;
    }

    /** 유저 상점 아래 바: 나가기 / 왼쪽으로 / 페이지수(가운데) / 오른쪽으로 / 물건 추가(오른쪽 끝) */
    private void userBar(MenuHolder h, Player p, int page, int pages, Consumer<Integer> go) {
        int base = (h.rows - 1) * 9;
        pane(h, base, base + 8);
        h.set(base, Items.icon(Material.BARRIER, "<red>나가기"), Player::closeInventory);
        if (page > 0) h.set(base + 3, Items.icon(Material.ARROW, "<yellow>◀ 왼쪽으로"), pl -> go.accept(page - 1));
        h.set(base + 4, Items.icon(Material.OAK_SIGN, "<white>페이지 " + (page + 1) + " / " + pages), null);
        if (page < pages - 1) h.set(base + 5, Items.icon(Material.ARROW, "<yellow>오른쪽으로 ▶"), pl -> go.accept(page + 1));
        h.set(base + 8, Items.icon(Material.WRITABLE_BOOK, "<aqua>물건 추가",
                "<gray>손에 든 물건을 등록합니다.", "<yellow>클릭: 가격을 채팅으로 입력"), pl -> startAddListing(pl));
    }

    private void startAddListing(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) { bar(p, "<red>손에 판매할 물건을 들고 누르세요."); return; }
        if (Items.isMagnetItem(hand)) { bar(p, "<red>자석석은 등록할 수 없습니다."); return; }
        final ItemStack snap = hand.clone();
        final long max = plugin.getConfig().getLong("shop.max-listing-price", 100_000_000L);
        startPrompt(p, List.of(
                "손에 든 물건 전부(" + snap.getAmount() + "개)의 판매 가격을 채팅으로 입력하세요.",
                "숫자만 입력하세요. (1원 ~ " + NationManager.fmt(max) + ")",
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (text.equals("취소")) { pl.sendMessage(Msg.c("<red>등록이 취소되었습니다.")); openShop(pl, 2, 0); return true; }
            long v;
            try {
                v = Long.parseLong(text);
            } catch (NumberFormatException ex) {
                pl.sendMessage(Msg.c("<red>숫자만 입력하세요. (취소하려면 '취소')"));
                return false;
            }
            if (v < 1 || v > max) { pl.sendMessage(Msg.c("<red>1원 ~ " + NationManager.fmt(max) + " 사이로 입력하세요.")); return false; }
            openListingConfirm(pl, snap, v);
            return true;
        });
    }

    /** 가운데에 물건, 왼쪽 초록 양털(수락) / 오른쪽 빨간 양털(취소) */
    private void openListingConfirm(Player p, ItemStack snap, long price) {
        MenuHolder h = new MenuHolder("<dark_green>상품 등록 확인", 3);
        h.set(13, Items.loreOn(snap, List.of("<yellow>가격: " + NationManager.fmt(price))), null);
        h.set(11, Items.icon(Material.LIME_WOOL, "<green>수락", "<gray>유저 상점에 등록합니다."), pl -> {
            if (!pl.getInventory().getItemInMainHand().equals(snap)) {
                bar(pl, "<red>손에 든 물건이 바뀌었습니다. 다시 시도하세요.");
                openShop(pl, 2, 0);
                return;
            }
            String err = m.addListing(pl, price);
            if (err != null) pl.sendMessage(Msg.c("<red>" + err));
            else pl.sendMessage(Msg.c("<green>유저 상점에 등록했습니다. (" + NationManager.fmt(price) + ")"));
            openShop(pl, 2, 0);
        });
        h.set(15, Items.icon(Material.RED_WOOL, "<red>취소"), pl -> openShop(pl, 2, 0));
        p.openInventory(h.inv);
    }

    // ===================== 관리자: 명령어 허용 설정 (하나씩 켜고 끄기) =====================
    public void openCommandSettings(Player p) {
        MenuHolder h = new MenuHolder("<dark_red>명령어 허용 설정", 3);
        renderCommandSettings(h);
        p.openInventory(h.inv);
    }

    private void renderCommandSettings(MenuHolder h) {
        h.clearAll();
        int slot = 0;
        for (String sub : NationCommand.SUBS) {
            boolean allowed = plugin.commandAllowed(sub);
            h.set(slot++, Items.icon(allowed ? Material.LIME_WOOL : Material.RED_WOOL,
                    (allowed ? "<green>" : "<red>") + "/국가 " + sub,
                    allowed ? "<green>일반 유저 사용 가능" : "<red>관리자 전용",
                    "<gray>클릭: " + (allowed ? "관리자 전용으로 변경" : "일반 유저에게 허용")), pl -> {
                if (!pl.hasPermission("nationwar.admin")) return;
                plugin.setCommandAllowed(sub, !plugin.commandAllowed(sub));
                renderCommandSettings(h);
            });
        }
        nav(h, null);
    }

    // ===================== 출입 시도: 통행증 창 =====================
    public void tryOpenPass(Player p, Claim c) {
        long now = System.currentTimeMillis();
        if (passCooldown.getOrDefault(p.getUniqueId(), 0L) > now) return;
        if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof MenuHolder) return;
        passCooldown.put(p.getUniqueId(), now + 1500);
        Bukkit.getScheduler().runTask(plugin, () -> openPass(p, c));
    }

    private void openPass(Player p, Claim c) {
        Nation tn = m.nations.get(c.nation);
        if (tn == null || !p.isOnline()) return;
        long fee = m.tollOf(c);
        MenuHolder h = new MenuHolder("<dark_red>출입금지: " + Msg.esc(tn.name), 2);
        h.set(2, Items.icon(Material.LIME_WOOL, "<green>통행증 발행",
                "<gray>통행료: <white>" + NationManager.fmt(fee),
                "<gray>유효시간: " + plugin.getConfig().getInt("pass.duration-seconds", 60) + "초",
                "<gray>통행 중에는 상호작용/PvP 불가"), pl -> {
            pl.closeInventory();
            String err = m.buyPass(pl, c);
            if (err != null) Msg.send(pl, "<red>" + err);
        });
        h.set(6, Items.icon(Material.RED_WOOL, "<yellow>비켜가기", "<gray>들어가지 않고 돌아갑니다."), Player::closeInventory);
        nav(h, null);
        h.onClose = () -> passCooldown.put(p.getUniqueId(), System.currentTimeMillis() + 3000);
        p.openInventory(h.inv);
    }

    // ===================== 정복 선택: 왼쪽 초록 양털(병합) / 오른쪽 빨간 양털(식민지) =====================
    public void openConquest(Player p, UUID bnId, UUID vnId) {
        Nation vn = m.nations.get(vnId);
        if (vn == null) return;
        MenuHolder h = new MenuHolder("<dark_red>정복 방식 선택: " + Msg.esc(vn.name), 2);
        int min = plugin.getConfig().getInt("war.conquest-lock-minutes", 10);
        h.set(2, Items.icon(Material.LIME_WOOL, "<green>병합",
                "<gray>상대 땅이 내 땅이 됩니다.", "<gray>상대 시민은 머무르거나 떠날 수 있습니다.", "<red>식민지로 변경 불가"), pl -> {
            pl.closeInventory();
            m.chooseAnnex(pl, bnId, vnId);
        });
        h.set(6, Items.icon(Material.RED_WOOL, "<red>식민지",
                "<gray>상대 땅은 '식민지 땅'으로 따로 분류됩니다.", "<gray>시민들의 돈을 모두 빼앗습니다.", "<red>선택 후 " + min + "분간 변경 불가"), pl -> {
            pl.closeInventory();
            m.chooseColony(pl, bnId, vnId);
        });
        nav(h, null);
        invulnerable.add(p.getUniqueId());
        h.onClose = () -> invulnerable.remove(p.getUniqueId()); // 창이 켜져 있는 동안 무적
        p.openInventory(h.inv);
    }

    // ===================== 병합된 시민: 머무르기 / 떠나기 =====================
    public void openAnnexChoice(Player p, Nation bn) {
        MenuHolder h = new MenuHolder("<dark_red>정복당했습니다", 2);
        h.set(2, Items.icon(Material.LIME_WOOL, "<green>머무르기", "<gray>" + Msg.esc(bn.name) + " 땅의 시민이 됩니다."), pl -> {
            pl.closeInventory();
            Msg.send(pl, "<yellow>" + Msg.esc(bn.name) + " 의 시민이 되었습니다.");
        });
        h.set(6, Items.icon(Material.RED_WOOL, "<red>떠나기", "<gray>이 땅을 떠납니다."), pl -> {
            pl.closeInventory();
            m.leaveFree(pl.getUniqueId());
            Msg.send(pl, "<yellow>땅을 떠났습니다.");
        });
        nav(h, null);
        p.openInventory(h.inv);
    }

    // ===================== 식민지 관리 =====================
    public void openColonies(Player p) {
        MenuHolder h = new MenuHolder("<dark_red>식민지 땅", 3);
        int slot = 0;
        for (Nation col : m.colonies(p.getUniqueId())) {
            if (slot >= 18) break;
            List<String> lore = new ArrayList<>();
            long area = 0;
            for (Claim c : m.claimsOfNation(col.id)) area += c.area();
            lore.add("<gray>시민 " + col.members.size() + "명 / 땅 " + String.format("%,d", area) + "블록");
            int k = 0;
            for (Claim c : m.claimsOfNation(col.id)) {
                if (k++ >= 6) { lore.add("<gray>..."); break; }
                lore.add("<white>" + c.coord());
            }
            long left = col.lockUntil - System.currentTimeMillis();
            lore.add(left > 0 ? "<red>변경 불가: " + (left / 1000) + "초 남음" : "<green>변경 가능");
            lore.add("<yellow>클릭: 식민지 변경");
            h.set(slot++, Items.icon(Material.WHITE_BANNER, "<gold>" + Msg.esc(col.name), lore), pl -> openColonyChange(pl, col));
        }
        nav(h, this::openLand);
        p.openInventory(h.inv);
    }

    /** 식민지 변경: 왼쪽 초록 양털(병합) / 오른쪽 빨간 양털(독립국가) */
    public void openColonyChange(Player p, Nation col) {
        MenuHolder h = new MenuHolder("<dark_red>식민지 변경: " + Msg.esc(col.name), 2);
        long left = col.lockUntil - System.currentTimeMillis();
        String lock = left > 0 ? "<red>변경 불가: " + (left / 1000) + "초 남음" : "<green>변경 가능";
        h.set(2, Items.icon(Material.LIME_WOOL, "<green>병합", "<gray>식민지가 내 땅이 됩니다.", lock), pl -> {
            result(pl, m.annexColony(pl, col), "병합되었습니다.");
            pl.closeInventory();
        });
        h.set(4, Items.icon(Material.WHITE_BANNER, "<gold>" + Msg.esc(col.name), lock), null);
        h.set(6, Items.icon(Material.RED_WOOL, "<red>독립국가", "<gray>식민지가 독립국가가 됩니다.", lock), pl -> {
            result(pl, m.releaseColony(pl, col), "독립국가가 되었습니다.");
            pl.closeInventory();
        });
        nav(h, this::openColonies);
        p.openInventory(h.inv);
    }

    // ===================== 확인 창 =====================
    public void openConfirm(Player p, String title, String desc, Runnable yes, Consumer<Player> back) {
        MenuHolder h = new MenuHolder(title, 2);
        h.set(2, Items.icon(Material.LIME_WOOL, "<green>확인", desc), pl -> {
            pl.closeInventory();
            yes.run();
        });
        h.set(6, Items.icon(Material.RED_WOOL, "<red>취소"), Player::closeInventory);
        nav(h, back);
        p.openInventory(h.inv);
    }

    public void openLandPurchase(Player p, NationManager.Plan plan) {
        openConfirm(p, "<dark_green>땅 구매 확인",
                "<gray>" + String.format("%,d", plan.area()) + "블록 / 가격 " + NationManager.fmt(plan.price()), () ->
                        result(p, m.buyLand(p), "땅을 구매했습니다!"), null);
    }

    // ===================== 시민 추가 / 제거 =====================
    private void startInvitePrompt(Player p) {
        Component names = Msg.c("<yellow>초대할 수 있는 플레이어 (클릭): ");
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.getUniqueId().equals(p.getUniqueId()) || m.nationOf(o.getUniqueId()) != null) continue;
            names = names.append(Component.text(o.getName() + " ", NamedTextColor.GREEN)
                    .clickEvent(ClickEvent.runCommand("/국가 초대선택 " + o.getName())));
        }
        startPrompt(p, List.of("초대할 플레이어의 닉네임을 채팅으로 입력하거나 아래 이름을 클릭하세요.",
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (text.equals("취소")) { pl.sendMessage(Msg.c("<red>취소되었습니다.")); openLand(pl); return true; }
            Player t = Bukkit.getPlayerExact(text);
            if (t == null) { pl.sendMessage(Msg.c("<red>접속 중인 그 플레이어가 없습니다. 다시 입력하세요.")); return false; }
            String err = m.invite(pl, t);
            if (err != null) pl.sendMessage(Msg.c("<red>" + err));
            else pl.sendMessage(Msg.c("<green>" + Msg.esc(t.getName()) + " 님에게 초대를 보냈습니다."));
            openLand(pl);
            return true;
        });
        p.sendMessage(names);
    }

    public void openMembers(Player p) {
        Nation n = m.nationOf(p.getUniqueId());
        if (n == null || !n.leader.equals(p.getUniqueId())) return;
        MenuHolder h = new MenuHolder("<dark_green>시민 제거", 4);
        int slot = 0;
        for (UUID u : n.members) {
            if (u.equals(n.leader) || slot >= 27) continue;
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            final String nm = op.getName() == null ? "?" : op.getName();
            ItemStack head = Items.icon(Material.PLAYER_HEAD, "<white>" + Msg.esc(nm), "<red>클릭: 이 시민을 추방");
            if (head.getItemMeta() instanceof SkullMeta sm) {
                sm.setOwningPlayer(op);
                head.setItemMeta(sm);
            }
            h.set(slot++, head, pl -> openConfirm(pl, "<dark_red>시민 추방", "<gray>" + Msg.esc(nm) + " 님을 추방합니다.", () ->
                    result(pl, m.kick(pl, nm), "추방했습니다."), this::openMembers));
        }
        nav(h, this::openLand);
        p.openInventory(h.inv);
    }

    // ===================== 유저 상점 네고 =====================
    private static final class Neg {
        final UUID listingId, buyer, seller;
        long counter = -1;
        long expires;
        boolean prompting;

        Neg(UUID listingId, UUID buyer, UUID seller) {
            this.listingId = listingId;
            this.buyer = buyer;
            this.seller = seller;
        }
    }

    private final Map<UUID, Neg> negs = new HashMap<>();

    /** 1초마다 호출: 시간이 지난 네고를 실패 처리 */
    public void tick() {
        long now = System.currentTimeMillis();
        for (Neg n : new ArrayList<>(negs.values())) if (n.expires < now) failNeg(n, "시간 초과");
    }

    private void startNegotiation(Player buyer, UUID listingId) {
        NationManager.Listing li = m.listingOf(listingId);
        if (li == null) { bar(buyer, "<red>이미 팔렸거나 취소된 물건입니다."); return; }
        if (li.seller().equals(buyer.getUniqueId())) { bar(buyer, "<red>내가 등록한 물건입니다."); return; }
        Player seller = Bukkit.getPlayer(li.seller());
        if (seller == null) { bar(buyer, "<red>판매자가 오프라인이라 네고할 수 없습니다."); return; }
        if (negs.containsKey(listingId)) { bar(buyer, "<red>다른 구매자가 네고 중입니다."); return; }
        Neg n = new Neg(listingId, buyer.getUniqueId(), li.seller());
        n.expires = System.currentTimeMillis() + plugin.getConfig().getInt("market.negotiation-seconds", 120) * 1000L;
        negs.put(listingId, n);
        openNegBuyerWait(buyer, n, li);
        openNegSeller(seller, n, li);
        seller.sendMessage(Msg.c(Msg.PREFIX + "<yellow>" + Msg.esc(buyer.getName()) + " 님이 네고를 요청했습니다. ")
                .append(Msg.c("<green><bold>[응답 창 열기]").clickEvent(ClickEvent.runCommand("/국가 네고응답"))));
    }

    /** 판매자가 창을 닫았을 때 다시 열기 (/국가 네고응답) */
    public void reopenNegotiation(Player seller) {
        for (Neg n : negs.values()) {
            if (!n.seller.equals(seller.getUniqueId()) || n.counter >= 0 || n.prompting) continue;
            NationManager.Listing li = m.listingOf(n.listingId);
            if (li != null) { openNegSeller(seller, n, li); return; }
        }
        bar(seller, "<red>응답할 네고 요청이 없습니다.");
    }

    private void openNegBuyerWait(Player buyer, Neg n, NationManager.Listing li) {
        MenuHolder h = new MenuHolder("<gold>네고 요청 중", 3);
        h.tag = "neg:" + n.listingId;
        h.set(13, Items.loreOn(li.item(), List.of("<yellow>원래 가격: " + NationManager.fmt(li.price()),
                "<gray>판매자의 응답을 기다리는 중...", "<gray>대화는 일반 채팅/귓속말로 하세요.")), null);
        h.set(22, Items.icon(Material.RED_WOOL, "<red>네고 취소"), pl -> failNeg(n, "구매자가 취소"));
        buyer.openInventory(h.inv);
    }

    /** 판매자: 아래 왼쪽 네고 하기 / 아래 오른쪽 거절 */
    private void openNegSeller(Player seller, Neg n, NationManager.Listing li) {
        Player b = Bukkit.getPlayer(n.buyer);
        String bn = b == null ? "?" : Msg.esc(b.getName());
        MenuHolder h = new MenuHolder("<gold>네고 요청: " + bn, 3);
        h.tag = "neg:" + n.listingId;
        h.set(13, Items.loreOn(li.item(), List.of("<gray>구매자: <white>" + bn, "<yellow>원래 가격: " + NationManager.fmt(li.price()))), null);
        h.set(19, Items.icon(Material.LIME_WOOL, "<green>네고 하기", "<gray>더 낮은 가격을 채팅으로 제안합니다."), pl -> startCounterPrompt(pl, n, li));
        h.set(25, Items.icon(Material.RED_WOOL, "<red>거절", "<gray>네고 실패로 끝납니다."), pl -> failNeg(n, "판매자가 거절"));
        seller.openInventory(h.inv);
    }

    private void startCounterPrompt(Player seller, Neg n, NationManager.Listing li) {
        n.prompting = true;
        startPrompt(seller, List.of("구매자에게 제안할 가격을 채팅으로 입력하세요.",
                "숫자만 입력하세요. 원래 가격(" + NationManager.fmt(li.price()) + ")보다 낮아야 합니다.",
                "취소하려면 '취소' 라고 입력하세요."), (pl, text) -> {
            if (!negs.containsKey(n.listingId)) { pl.sendMessage(Msg.c("<red>네고가 이미 종료되었습니다.")); return true; }
            if (text.equals("취소")) { failNeg(n, "판매자가 취소"); return true; }
            long v;
            try {
                v = Long.parseLong(text);
            } catch (NumberFormatException ex) {
                pl.sendMessage(Msg.c("<red>숫자만 입력하세요. (취소하려면 '취소')"));
                return false;
            }
            if (v < 1 || v >= li.price()) {
                pl.sendMessage(Msg.c("<red>원래 가격(" + NationManager.fmt(li.price()) + ")보다 낮은 가격만 가능합니다. 다시 입력하세요."));
                return false;
            }
            Player b = Bukkit.getPlayer(n.buyer);
            if (b == null) { failNeg(n, "구매자가 오프라인"); return true; }
            n.prompting = false;
            n.counter = v;
            n.expires = System.currentTimeMillis() + plugin.getConfig().getInt("market.negotiation-seconds", 120) * 1000L;
            pl.sendMessage(Msg.c("<green>" + NationManager.fmt(v) + " 을(를) 제안했습니다. 구매자의 답을 기다립니다."));
            openNegBuyerOffer(b, n, li);
            return true;
        });
    }

    /** 구매자: 제안 가격이 적힌 블록, 왼쪽 수락 / 오른쪽 거절 */
    private void openNegBuyerOffer(Player buyer, Neg n, NationManager.Listing li) {
        MenuHolder h = new MenuHolder("<gold>가격 제안", 3);
        h.tag = "neg:" + n.listingId;
        h.set(13, Items.loreOn(li.item(), List.of("<gray>원래 가격: " + NationManager.fmt(li.price()),
                "<green>제안 가격: <white>" + NationManager.fmt(n.counter))), null);
        h.set(19, Items.icon(Material.LIME_WOOL, "<green>수락", "<gray>" + NationManager.fmt(n.counter) + " 에 구매합니다."), pl -> {
            String err = m.buyListingAt(pl, n.listingId, n.counter);
            if (err != null) { failNeg(n, err); return; }
            negs.remove(n.listingId);
            pl.closeInventory();
            Msg.send(pl, "<green>네고 성사! " + NationManager.fmt(n.counter) + " 에 구매했습니다.");
        });
        h.set(25, Items.icon(Material.RED_WOOL, "<red>거절", "<gray>네고 실패로 끝납니다."), pl -> failNeg(n, "구매자가 거절"));
        buyer.openInventory(h.inv);
    }

    private void failNeg(Neg n, String why) {
        if (negs.remove(n.listingId) == null) return;
        if (n.prompting) { prompts.remove(n.seller); n.prompting = false; }
        for (UUID u : new UUID[]{n.buyer, n.seller}) {
            Player pl = Bukkit.getPlayer(u);
            if (pl == null) continue;
            if (pl.getOpenInventory().getTopInventory().getHolder(false) instanceof MenuHolder mh
                    && ("neg:" + n.listingId).equals(mh.tag)) pl.closeInventory();
            Msg.send(pl, "<red>네고 실패 (" + why + ")");
        }
    }
}
