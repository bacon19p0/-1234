package com.nationwar;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class NationWarPlugin extends JavaPlugin {
    private NationManager manager;
    private GameListener listener;
    private Gui gui;

    public Gui gui() { return gui; }

    /** 일반 유저가 해당 /국가 하위 명령어를 쓸 수 있는지 (기본 false = 관리자 전용) */
    public boolean commandAllowed(String sub) { return getConfig().getBoolean("player-commands." + sub, false); }

    public void setCommandAllowed(String sub, boolean allowed) {
        getConfig().set("player-commands." + sub, allowed);
        saveConfig();
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Items.init(this);
        initRegion();
        manager = new NationManager(this);
        manager.load();
        gui = new Gui(this, manager);
        applyBorder();

        listener = new GameListener(this, manager, gui);
        getServer().getPluginManager().registerEvents(listener, this);
        listener.startTasks();
        new BorderRenderer(this, manager).start();
        manager.tickOres();
        Bukkit.getScheduler().runTaskTimer(this, manager::tickOres, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, () -> gui.tick(), 20L, 20L);

        NationCommand nc = new NationCommand(this, manager);
        PluginCommand c1 = getCommand("국가");
        if (c1 != null) { c1.setExecutor(nc); c1.setTabCompleter(nc); }
        AdminCommand ac = new AdminCommand(this, manager);
        PluginCommand c2 = getCommand("국가관리");
        if (c2 != null) { c2.setExecutor(ac); c2.setTabCompleter(ac); }

        Bukkit.getScheduler().runTaskTimer(this, () -> { if (manager.isDirty()) manager.save(); }, 600L, 600L);
        getLogger().info("NationWar 활성화! 국가 " + manager.nations.size() + "개 / 땅 " + manager.claims.size() + "청크");
    }

    @Override
    public void onDisable() {
        if (listener != null) listener.shutdown();
        if (manager != null) manager.save();
    }

    /** 최초 실행 시 월드 스폰을 구역 중심으로 고정 저장 */
    private void initRegion() {
        FileConfiguration c = getConfig();
        String wn = c.getString("region.world", "");
        World w = wn.isEmpty() ? (Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0)) : Bukkit.getWorld(wn);
        if (w == null) return;
        boolean changed = false;
        if (wn.isEmpty()) { c.set("region.world", w.getName()); changed = true; }
        if (!c.isSet("region.center-x")) {
            Location s = w.getSpawnLocation();
            c.set("region.center-x", s.getBlockX());
            c.set("region.center-z", s.getBlockZ());
            changed = true;
        }
        if (changed) saveConfig();
    }

    public void applyBorder() {
        FileConfiguration c = getConfig();
        if (!c.getBoolean("region.apply-world-border", true)) return;
        World w = Bukkit.getWorld(c.getString("region.world", "world"));
        if (w == null) return;
        WorldBorder b = w.getWorldBorder();
        b.setCenter(c.getInt("region.center-x", 0) + 0.0, c.getInt("region.center-z", 0) + 0.0);
        b.setSize(c.getInt("region.size-blocks", 10000));
    }
}
