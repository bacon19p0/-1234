#!/bin/sh
# JDK 25 + Maven 필요
mvn -B clean package && echo "완료: target/NationWar-4.0.0.jar 를 서버 plugins 폴더에 넣으세요."
